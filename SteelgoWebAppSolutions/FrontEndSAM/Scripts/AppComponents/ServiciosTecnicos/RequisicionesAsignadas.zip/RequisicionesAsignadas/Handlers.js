﻿function SuscribirEventos() {
    
};


function ActivarRefrescarGrid(idBoton) {
    tabActivo(idBoton);
    AjaxAccionesListado(idBoton);
}
